#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDS_STRING1                            40000
#define IDS_ERR_ID_RANGE                       40001
#define IDS_ERR_FLAG                           40002      
#define IDS_ERR_AXIS                           40003
#define IDS_ERR_BTN                            40004
#define IDS_ERR_POV                            40005
#define IDS_WRN_CREATE                         40006
#define IDS_ERR_NOGUI                          40007
#define IDS_ERR_32ON64                         40008
#define IDS_ERR_64ON32                         40009
#define IDS_ERR_ENABLE                         40010
