#pragma once
#define VER_H_ 4
#define VER_M_ 0
#define VER_L_ 1
#define BUILD 2

#define FILEVER				"4, 0, 1, 2"
#define PRODVER_TAG			"v4.0.1"
#define PRODVER_SHA1		"3d996b"

