# vJoy
Virtual Joystick

For much more go to vJoy web site: http://vjoystick.sourceforge.net

To build the project:

1. Pull the project

2. Run batch file BuildAll.bat

Caution:
You will need to install Visual Studio 2015 (Free)
To build the entire project including the driver you need to install the SDK and puchase a license to sign drivers.

Justin's notes:
1. Install Visual Studio 2013
2. Install Visual Studio 2015 Update 3
3. Install Windows 10 SDK 1511
4. Install Windows 10 WDK 1511
5. Install Windows 10 SDK 1607
6. Install Windows 10 WDK 1607
7. Install DotNet Framework 3.5 SP1
8. Install DotNet Framework 3.5 SDK (6.0.6001.18000.367-KRMSDK_EN.iso)
9. Install Innosetup 5
10. Place the DigiCert Utility on the desktop.
11. Copy the cfg_support_v1.lib file from C:\Program Files (x86)\Windows Kits\10\Lib\10.0.14393.0\km\x86 and x64 to C:\Program Files (x86)\Windows Kits\10\Lib\10.0.10586.0\km\x86 and x64
