##               vJoy installation##
Please READ instructions in [vJoy site](http://vjoystick.sourceforge.net/site/index.php)

[Do not hesitate to contact me](mailto://shaul_ei@users.sourceforge.net)

---------------------------------------------------------
# Release notes for 10-Jan-2015 #

New Revision - 2.1.5 - Merge of 2.1.4 and 2.0.5

vJoy with support for Force Feedback (FFB)
[Full description and instructions for the developer](http://sourceforge.net/projects/vjoystick/files/Alpha/2.1.5-100115/vJoy215RN.pdf/download)

---------------------------------------------------------
