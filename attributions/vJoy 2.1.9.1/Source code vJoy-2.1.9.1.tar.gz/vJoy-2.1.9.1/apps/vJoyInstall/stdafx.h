// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include "targetver.h"

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>
#include <basetyps.h>
#include <cfgmgr32.h>
#include <Setupapi.h>
#include <strsafe.h>
#include <Newdev.h>
#include <ks.h>
#include <initguid.h>


// TODO: reference additional headers your program requires here
