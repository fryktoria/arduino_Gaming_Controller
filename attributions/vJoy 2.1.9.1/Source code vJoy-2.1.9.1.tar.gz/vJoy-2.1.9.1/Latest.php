<?php
/* Redirect browser */
header("Location: http://sourceforge.net/projects/vjoystick/files/Beta%202.x/SDK/vJoy217SDK-260916.zip/download");
/* Make sure that code below does not get executed when we redirect. */
exit;
?>
